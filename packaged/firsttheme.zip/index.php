<?php get_header(); ?>

<?php if (have_posts()) { ?>
    <?php while (have_posts()) { ?>
        <?php the_post(); ?>
        <h2>
            <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a>
        </h2>
        <div>
            <?php firsttheme_post_meta(); ?>
        </div>
        <div>
            <?php the_excerpt(); ?>
        </div>
        <?php firsttheme_readmore_link(); ?>
    <?php } ?>
    <?php the_posts_pagination(); ?>
<?php } else { ?>
    <p><?php echo esc_html_e('Sorry, no posts matched your criteria.', 'firsttheme'); ?></p>
<?php } ?>

<?php

$comments = 1;

printf(esc_html(_n('One comment', '%s comments', $comments, 'firsttheme'), $comments));

_ex('Post', 'noun', 'firsttheme')

?>


<?php get_footer(); ?>