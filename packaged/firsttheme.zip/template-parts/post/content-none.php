<p>
	<?php echo apply_filters( 'firsttheme_no_posts_text', esc_html__( 'Sorry, no posts matched your criteria.', 'firsttheme' ) ); ?>
</p>