<?php

/**
 * Plugin Name
 *
 * @package           metaboxes-pluginname
 * @author            Your Name
 * @license           GPL-2.0-or-later
 *
 * @wordpress-plugin
 * Plugin Name:       metaboxes-metaboxes
 * Plugin URI:        https://chucksmith.dev
 * Description:       Adding Metaboxes for metaboxes
 * Version:           1.0.0
 * Requires at least: 5.6
 * Requires PHP:      7.2
 * Author:            Chuck Smith
 * Author URI:        https://chucksmith.dev
 * Text Domain:       metaboxes-plugin
 * License:           GPL v2 or later
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 */

if( !defined('WPINC')) {
	die;
}

include_once(__NAMESPACE__ . 'inc/metaboxes.php');
include_once(__NAMESPACE__ . 'inc/enqueue-assets.php');
