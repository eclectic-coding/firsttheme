<?php

add_action( 'admin_enqueue_scripts', 'metaboxes_pluginname_admin_scripts' );
function metaboxes_pluginname_admin_scripts() {
	global $pagenow;
	if ( $pagenow !== 'post.php' ) {
		return;
	}
	wp_enqueue_script( 'metaboxes-_pluginname-admin-scripts', plugins_url(
		'metaboxes-metaboxes/dist/assets/js/admin.js' ), array( 'jquery' ),
		'1.0.0', true );

	wp_enqueue_style( 'metaboxes-_pluginname-admin-stylesheet', plugins_url(
		'metaboxes-metaboxes/dist/assets/css/admin.css' ), array(),
		'1.0.0', 'all' );
}
